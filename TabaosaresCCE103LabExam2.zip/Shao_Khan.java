package tabaosares;

public class Shao_Khan implements Enemy, LandEnemy {


	   @Override
	    public String LandMagic() {
			return "Shao Khan is Good in Land Fights";   
	    }

	    @Override
	    public String behavior() {
			return "                "+"I am Shao Khan"
				   +"\n---------------Behavior-------------"
				   +"\nKahn is also extremely manipulative, malevolent, and cruel, so he desires only to conquer other realms and add them to his own.";
	    }

	    @Override
	    public String origin() {
			return "\nMortal Kombat"
				   +"\n"
				   +"\n"
				   +"|  Land |";
	    }
	}
		

