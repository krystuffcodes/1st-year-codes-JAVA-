package tabaosares;

public class Creeper implements Enemy, LandEnemy, FireEnemy{

		
    @Override
    public String FireMagic() {      
		return "Capable of exploding his self";    
    }

    @Override
    public String LandMagic() {
		return "Good at chasing the enemy";   
    }

    @Override
    public String behavior() {
		return "                "+"I am Creeper"
			   +"\n---------------Behavior-------------"
			   +"\nCreepers will start chasing a player once they are within a 16 block radius of the creeper.";
    }

    @Override
    public String origin() {
		return "\nMineCraft"
			   +"\n"
			   +"\n"
			   +"| Fire  -  Land |";
    }
}
	


