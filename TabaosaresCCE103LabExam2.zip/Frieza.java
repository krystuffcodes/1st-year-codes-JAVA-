package tabaosares;

public class Frieza implements Enemy, LandEnemy, AirEnemy {

	
    @Override
    public String FlyMagic() {      
		return "Good at figthing in the mid-air.";    
    }

    @Override
    public String LandMagic() {
		return "Capable of fighting in land";   
    }

    @Override
    public String behavior() {
		return  "                " + "I am Frieza"
			   +"\n---------------Behavior-------------"
			   +"\nHe is shown to be manipulative and deceitful";
    }

    @Override
    public String origin() {
		return "\nDragon Ball"
			   +"\n"
			   +"\n"
			   +"| Air  -  Land |";
    }
}
	
