package tabaosares;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class TabaosaresCCE103LabExam2 implements ActionListener {

    private static JButton Murloc, Frieza, Creeper, HeadCrab, Shao_Khan, Clear;
    private static JTextArea Result;

    public static void main(String[] args) {
    	
    	//Frames
        JFrame frame = new JFrame();
        frame.setSize(530, 600);
        frame.setTitle("LabExam2Tabaosares");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel p = new JPanel();

        frame.add(p);
        p.setLayout(null);

        // JLabeL
        JLabel title = new JLabel("Enemy ");
        title.setBounds(230, 10, 250, 55);
        p.add(title);
        Font fn = new Font("Arial", Font.BOLD, 25);
        title.setFont(fn);

        // Characters - JButton
        Murloc = new JButton("Murloc");
        Murloc.setBounds(30, 100, 120, 45);
        Murloc.addActionListener(new TabaosaresCCE103LabExam2());
        p.add(Murloc);

        Frieza = new JButton("Frieza");
        Frieza.setBounds(30, 180, 120, 45);
        Frieza.addActionListener(new TabaosaresCCE103LabExam2());
        p.add(Frieza);

        Creeper = new JButton("Creeper");
        Creeper.setBounds(30, 260, 120, 45);
        Creeper.addActionListener(new TabaosaresCCE103LabExam2());
        p.add(Creeper);

        HeadCrab = new JButton("HeadCrab");
        HeadCrab.setBounds(30, 340, 120, 45);
        HeadCrab.addActionListener(new TabaosaresCCE103LabExam2());
        p.add(HeadCrab);

        Shao_Khan = new JButton("Shao_Khan");
        Shao_Khan.setBounds(30, 420, 120, 45);
        Shao_Khan.addActionListener(new TabaosaresCCE103LabExam2());
        p.add(Shao_Khan);

        // ClearButton
        Clear = new JButton("Clear");
        Clear.setBounds(280, 480, 120, 35);
        Clear.addActionListener(new TabaosaresCCE103LabExam2());
        p.add(Clear);

        // Result
        Result = new JTextArea();
        Result.setEditable(false);
        Result.setLineWrap(true);
        Result.setWrapStyleWord(true);
        Result.setBounds(170, 100, 330, 360);
        p.add(Result);

        frame.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Murloc) {
            Enemy enemy = new Murloc();
            Result.append(enemy.behavior() + "\n");
            Result.append("\n---------------Origin-----------------");
            Result.append(enemy.origin());
            Result.append(((Murloc) enemy).WaterMagic()+ "\n");
            Result.append(((Murloc) enemy).LandMagic()+ "\n");
            
        } else if (e.getSource() == Frieza) {
            Enemy enemy = new Frieza();;
            Result.append(enemy.behavior() + "\n");
            Result.append("\n---------------Origin-----------------");
            Result.append(enemy.origin() + "\n");
            Result.append(((Frieza) enemy).FlyMagic()+ "\n");
            Result.append(((Frieza) enemy).LandMagic()+ "\n");
            
        } else if (e.getSource() == Creeper) {
            Enemy enemy = new Creeper();
            Result.append(enemy.behavior() + "\n");
            Result.append("\n---------------Origin-----------------");
            Result.append(enemy.origin() + "\n");
            Result.append(((Creeper) enemy).FireMagic()+ "\n");
            Result.append(((Creeper) enemy).LandMagic()+ "\n");
            
        } else if (e.getSource() == HeadCrab) {
            Enemy enemy = new HeadCrab();
            Result.append(enemy.behavior() + "\n");
            Result.append("\n---------------Origin-----------------");
            Result.append(enemy.origin() + "\n");
            Result.append(((HeadCrab) enemy).LandMagic()+ "\n");
            
        } else if (e.getSource() == Shao_Khan) {
            Enemy enemy = new Shao_Khan();
            Result.append(enemy.behavior() + "\n");
            Result.append("\n---------------Origin-----------------");
            Result.append(enemy.origin() + "\n");
            Result.append(((Shao_Khan) enemy).LandMagic()+ "\n");
            
        } else if (e.getSource() == Clear) {
            Result.setText("");
        }
    }
}
