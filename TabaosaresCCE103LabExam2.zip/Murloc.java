package tabaosares;

public class Murloc implements Enemy, LandEnemy, WaterEnemy{

    @Override
    public String WaterMagic() {      
		return "Capable of fighting in land.";    
    }

    @Override
    public String LandMagic() {
		return "Capable of fighting in water.";   
    }

    @Override
    public String behavior() {
		return "                " + "I am Murloc"
			   +"\n---------------Behavior-------------"
			   +"\nuntamed, or quiet and curious";
    }

    @Override
    public String origin() {
		return "\nWorld of Warcraft"
			   +"\n"
			   +"\n"
		       +"| Water  -  Land |"
			   +"\n";
    }
}