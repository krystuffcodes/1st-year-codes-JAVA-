package tabaosares;

public interface WaterEnemy {

	
	
	String WaterMagic();
	
}
