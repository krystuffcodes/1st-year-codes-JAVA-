package tabaosares;

public interface AirEnemy {

	
	String FlyMagic();
	
}
