package tabaosares;

public class HeadCrab implements Enemy, LandEnemy {

	
   @Override
    public String LandMagic() {
		return "Killing enemy using his Jawless Mouth";   
    }

    @Override
    public String behavior() {
		return "                "+"I am HeadCrab"
			   +"\n---------------Behavior-------------"
			   +"\nthe headcrab eats away at the host's head and latches onto their brain.";
    }

    @Override
    public String origin() {
		return "\nHalf-Life"
			   +"\n"
			   +"\n"
			   +"| Land |";
    }
}
	
