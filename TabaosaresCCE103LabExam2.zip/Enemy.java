package tabaosares;

public interface Enemy {

	String behavior();
	
	String origin();
	
}
