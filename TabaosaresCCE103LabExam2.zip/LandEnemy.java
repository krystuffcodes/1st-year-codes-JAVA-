package tabaosares;

public interface LandEnemy {

	String LandMagic();
	
}
