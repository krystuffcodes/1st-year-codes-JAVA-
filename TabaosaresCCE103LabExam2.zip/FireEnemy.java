package tabaosares;

public interface FireEnemy {

	
	String FireMagic();
	
}
