package inheretance;

public class Lander extends Defenders {

	//attributes
	String versatile;
	
	Lander(String name, String speed, int firepower, String versatile) {
		super(name, speed, firepower);
		
		this.versatile = versatile;
	}
	
	void info()
	{
		super.info();
	}
	
	void attackRole()
	{
		System.out.println(name +"'s role: "+ versatile);
	}
}
