package inheretance;

public class Bomber extends Defenders{

	String strategic;
	
	Bomber(String name, String speed, int firepower, String strategic) {
		super(name, speed, firepower);
		
		this.strategic = strategic;
	}

	void info()
	{
		super.info();
	}
	
	void roleStrategic()
	{
		System.out.println(name + "'s role: "+strategic);
	}
}
