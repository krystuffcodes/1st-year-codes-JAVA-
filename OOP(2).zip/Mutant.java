package inheretance;

public class Mutant extends Defenders {

	//attributes
	String aggressor;
	
	Mutant(String name, String speed, int firepower, String aggressor) {
		super(name, speed, firepower);
		
		this.aggressor = aggressor;
	}
	
	void info()
	{
		super.info();
	}
	
	void roleAggressor()
	{
		System.out.println(name+"'s role: "+aggressor);
	}
	

}
