package inheretance;

import java.util.Scanner;

public class Main_Defender {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		int choice;
		boolean exit = false;
		

		do {
		System.out.println();
		System.out.println("---DEFENDER'S CHARACTERS---");		
		System.out.println("1. Lander");
		System.out.println("2. Mutant");
		System.out.println("3. Bomber");
		System.out.println("4. Exit");
		System.out.println("CHOOSE: ");
		choice = input.nextInt();

		switch (choice)
		{
		case 1:
		Lander l = new Lander("Lander", "Slow", 3, "Fires shots intermittently.\r\n"
				+ "Descends briefly to pick up humanoids before returning.");
		System.out.println();
		l.info();
		System.out.println();
		l.attackRole();
			break;
		
		case 2:
		Mutant m = new Mutant("Mutant", "Fast", 5, "Attacks aggressively upon spotting the player.\r\n"
				+ "Utilizes erratic flight patterns for increased difficulty.");
		System.out.println();
		m.info();
		System.out.println();
		m.roleAggressor();
			break;
			
		case 3:
		Bomber b = new Bomber("Bomber", "Slow", 7, "Leaves hazardous bomb trails.\r\n"
				+ "Triggers the player's ship destruction upon contact.");
		System.out.println();
		b.info();
		System.out.println();
		b.roleStrategic();
			break;
		
		case 4:
			exit = true;
			break;
		
	    default:
            System.out.println("Invalid choice. Please choose again.");
            break;
    }

    if (!exit) {
		System.out.println();
        System.out.print("Do you want to continue? (yes/no): ");
        String cc = input.next();
        if (!cc.equalsIgnoreCase("yes")) {
            exit = true;
            
            
        }
    }

} while (!exit);
System.out.println();
System.out.println("Exiting the program.");
System.out.println("Thank you for using =).");

	}

}
