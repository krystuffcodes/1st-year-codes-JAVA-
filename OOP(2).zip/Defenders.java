package inheretance;

public class Defenders {

	//attributes
	String name;
	String speed;
	int firepower;
	
	//constructor
	Defenders(String name, String speed, int firepower)
	{
		this.name = name;
		this.speed = speed;
		this.firepower = firepower;
	}
	
	void info()
	{
		System.out.println("Name: "+ name);
		System.out.println("Speed: "+ speed);
		System.out.println("Firepower: "+ firepower);	
	}
	
	
	
}
