package Abstraction6496;

public interface AirEnemy {

}
