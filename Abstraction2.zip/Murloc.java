package Abstraction6496;

public class Murloc {

}
