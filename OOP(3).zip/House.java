package inherent;

public class House {
	
	//attributes
	String address;
	String color;
	double area;
	
	//constructor
	House(String address, String color, double area)
	{
		this.address = address;
		this.color = color;
		this.area = area;
	}

	//methods
	
	void openDoor()
	{
		System.out.println("Door has been opened.");
	}
	
	void info()
	{
		System.out.println("Address of the House: "+ address);
		System.out.println("Color of the House: "+ color);
		System.out.println("Area of the House: "+ area);	
	}
	
	
	void closeDoor()
	{
		System.out.println("Door has been closed");
	}
	

}
