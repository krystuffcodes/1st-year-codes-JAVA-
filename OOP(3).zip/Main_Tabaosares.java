package CCE103OOP;

public class Main_Tabaosares {

	public static void main(String[] args) {
		
		House h = new House("MHDI, Nacilla Road, Davao City", "Brown", 300.7);
		
		h.openDoor();
		System.out.println();
		h.info();
		System.out.println();
		h.closeDoor();

	}

}
